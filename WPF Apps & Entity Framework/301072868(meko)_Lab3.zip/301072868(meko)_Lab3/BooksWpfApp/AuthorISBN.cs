﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace BooksWpfApp
{
    public class AuthorISBN
    {
        public int AuthorID { get; set; }

        public string ISBN { get; set; }
    }
}
